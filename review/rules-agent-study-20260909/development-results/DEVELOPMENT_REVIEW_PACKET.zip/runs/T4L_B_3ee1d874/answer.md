已提交证据化答案，核心结论如下：

- **相对单独生成模型：**在 WT T4L、给定候选池和模拟条件下，AMS 通过 GenAI 种子加无偏 MD/MSM 访问了单独 GenAI 集合通常未覆盖的 closed、buried 等区域；但去掉 **AF-cluster** 后 closed state 未被采到，说明优势明显依赖种子多样性。
- **相对 EMD：**AMS 覆盖了同一四态模型的全部状态，且三个状态的人口接近 EMD：  
  exposed/open：38.3% vs 39.1%；  
  buried/open：58.7% vs 54.0%；  
  buried/closed：2.3% vs 2.9%。  
  但 exposed/closed 仅为 0.7% vs EMD 的 3.9%，仍被低估。
- **相对实验观测：**AMS 的 MSM 加权 FRET 分布包含实验 smFRET 所见的 open 和稀有 closed 宏观信号；但过渡区存在偏离，模拟 FRET 还依赖 MSM 聚类、特征、力场和水模型。
- **尚未支持的强结论：**这些结果不能证明 AMS 给出了真实平衡占比、完整且唯一的构象分布、真实交换速率或转换机制，也不能证明其普遍优于 EMD，更不能据此推出功能因果解释。
- **关键限制：**EMD 原始轨迹及完整预测数据不可得，因此无法完成严格的逐点 AMS–EMD 重分析和独立统计比较。所有人口结论都受候选池、CV、状态边界、MSM 和模拟条件约束。