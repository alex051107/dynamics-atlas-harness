# Matched DHFR sources

Paper DOI10.1021/acs.jcim.3c00818 (2023), PMC10428214 full JATS via EuropePMC. CC-BY4.0. Dataset10.5281/zenodo.7966540, CC-BY4.0. Author code commit eba9948e57f25cec9eb9bdb50cfdb234fc23fffc; no repository license declared, preserved as local scientific source reference.

Paper-reported: E.coli DHFR, WT and L28R; closed starting templates6XG5/6XG4; cofactorNADPH in all simulations; protonated TMP/4DTMP; CHARMM36, TIP3P,0.15M KCl,NPT1atm,2fs; duplicated210ns and1μs production. Temperature numeric value not found in consulted System Preparation text, do not invent. His6-tagged experimental protein, MTENpH7,100mMNaCl versus untagged simulated construct and0.15MKCl; solvent and preparation are not identical. Paper prints200mM NADPH in assay method; retained as printed, not silently corrected. These sources support qualitative comparison of local structural interactions and condition-specific experimental response; no direct equality between distance and inhibition.

Input-verified facts are in trajectory_metadata.tsv, atom_mapping.tsv and DOWNLOAD_MANIFEST.json. Nominal time derives from deposit description; regenerated DCDheader is not a physical timestep authority. Ligand residue IDs are resolved from three uniquely named oxygens rather than copied from hardcoded author script residue300/303.
