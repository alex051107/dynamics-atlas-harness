以下为分析提醒，可质疑；与资料冲突时以资料为准并说明。

**[C012-RULE-003]** 项目归纳的本题检查（不是来源论文的普适条款）
- {"claim_scope": "ENSEMBLE_SUPPORT", "obligation_id": "case-claim-ceiling--case", "reason_from_input": "Case Q-D-defect requests claim level SOURCE_LOCAL_CONSISTENCY; a separate claim-ceiling review is required before any scientific route is emitted.", "required_check": "Keep source-local consistency, cross-source comparability, ensemble support, population, kinetics and mechanism as separate claim levels; evidence evaluation must not exceed the requested and supported level.", "target": {"target_type": "CASE"}}
原条款（来源 wankowicz_bonomi_2026_ensemble_prediction；方法家族 GENERAL_ENSEMBLE；transfer_scope：perspective cannot eliminate inverse-problem and prior limits）
在 G0>G1>G4>G5 的重点检查中要求 ground truth, representation, comparison, uncertainty and intended-use status；若无法验证则走 GROUND_TRUTH_OR_VALIDATION_MISSING。
必填：ground truth, representation, comparison, uncertainty and intended-use status　弃权路线：GROUND_TRUTH_OR_VALIDATION_MISSING

**[C012-RULE-001]** 项目归纳的本题检查（不是来源论文的普适条款）
- {"claim_scope": "SOURCE_LOCAL_CONSISTENCY", "obligation_id": "source-observability-and-native-semantics--source--dhfr_md", "reason_from_input": "Source dhfr_md uses registered method MD_TRAJECTORY with evidence role DIAGNOSTIC; its scientific meaning must remain source specific.", "required_check": "Compare the claim-level observability target with this source's native observable, estimand, time semantics, spatial support and detection boundary without assigning an adequacy verdict from metadata alone.", "target": {"source_ids": ["dhfr_md"], "target_type": "SOURCE"}}
原条款（来源 wankowicz_bonomi_2026_ensemble_prediction；方法家族 GENERAL_ENSEMBLE；transfer_scope：infrastructure perspective, not a completed benchmark）
在 G0>G1>G2>G3>G4>G5 的重点检查中要求 condition, claim, modality-specific observable, forward model, uncertainty and intended use；若无法验证则走 BENCHMARK_SCOPE_UNDEFINED。
原文条件：condition, claim, modality-specific observable, forward model, uncertainty and intended use；原文弃权路线：BENCHMARK_SCOPE_UNDEFINED
本题适用性未确认：以上条件不作为必填或弃权理由。

**[C001-RULE-002]** 项目归纳的本题检查（不是来源论文的普适条款）
- {"claim_scope": "SOURCE_LOCAL_CONSISTENCY", "obligation_id": "source-uncertainty-provenance--source--dhfr_md", "reason_from_input": "Source dhfr_md carries uncertainty status PARTIAL and therefore needs an explicit source-level uncertainty review.", "required_check": "Audit the uncertainty components and provenance for this source before treating numerical or qualitative agreement as evidence.", "target": {"source_ids": ["dhfr_md"], "target_type": "SOURCE"}}
原条款（来源 hellenkamp_2018_smfret_benchmark；方法家族 smFRET；transfer_scope：requires explicit calibration provenance）
在 G1>G2>G3 的重点检查中要求 correction, R0, dye/AV and propagated measurement/model uncertainty；若无法验证则走 UNCERTAINTY_UNRESOLVED。
原文条件：correction, R0, dye/AV and propagated measurement/model uncertainty；原文弃权路线：UNCERTAINTY_UNRESOLVED
本题适用性未确认：以上条件不作为必填或弃权理由。

以上提醒可质疑。
