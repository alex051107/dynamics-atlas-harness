def check_submission(record, tool_outputs, source):
    raise RuntimeError("E2 checker not installed in this experiment")
