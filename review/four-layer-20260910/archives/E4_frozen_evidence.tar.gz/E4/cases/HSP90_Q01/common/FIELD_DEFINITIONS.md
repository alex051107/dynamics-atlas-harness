# Field definitions for the delivered HSP90 tables

The reporting unit is trajectory: 40 trajectories, 20 closed_seeded and 20 open_seeded. Frames describe the time course within each trajectory. Seed lineage is recorded in trajectory_time_anatomy.tsv. The names R46A/R60A refer to the starting-structure lineage; see the source card for the sequence audit and its provenance.

The delivered time window is 20–1020 ns, 1001 points per trajectory, at 1 ns intervals. Time zero follows the original simulation. See HSP90_SOURCE_AND_RUN_CARD.json.

`d_open_medoid_A` and `d_closed_medoid_A` are lid RMSD values after core alignment relative to the open/closed reference medoids. `geometry_delta_A = d_closed_medoid_A - d_open_medoid_A`. `nearest_open_A` and `nearest_closed_A` instead use the nearest member of each reference ensemble. They are separate fields. `contact_margin_A` is the deposited closed-state contact-violation readout minus the open-state readout. Distances/margins are in angstroms. The historical producer is run_hsp90_v1.py, lines 1110–1145 (provenance recorded in the inventory).

For the time-anatomy tables, a frame has direction OPEN_CONSENSUS when geometry_delta_A > 0 and contact_margin_A > 0; CLOSED_CONSENSUS when both are < 0; otherwise READOUT_CONFLICT. Zeros enter the conflict category. These are the existing zero-sign criteria, with no tuning in this preparation.

`state_core` is a separate assignment: C when delta <= theta_closed and d_closed <= radius_closed; O when delta >= theta_open and d_open <= radius_open; otherwise U. Exact medoid indices, thresholds and radii are in state_core_definition.json. Its recorded meaning is anchor-relative structural support core.

A contiguous run contains consecutive frames with one direction label. trajectory_time_anatomy.tsv contains three rows per trajectory, using persistence_saved_frames thresholds 5, 20 and 50. These are repeated summaries of one trajectory, not 120 trajectories.

first_persistent_direction is the first non-conflict run with at least the specified number of saved frames. opposite_direction_departure_candidate records a later persistent run with the opposite direction. return_candidate records a persistent run in the initial persistent direction after that departure. The reference direction is the first persistent run, which may differ from the starting-structure category represented by seed_lineage.

persistence_ns and length_ns use the historical saved-frame-count convention: five consecutive points sampled 1 ns apart span 4 ns between their endpoints. start_time_ns/end_time_ns give the endpoints separately.

The nominal 50 ns display bins contain 50 saved frames, classified from the within-bin median geometry and contact margins using the same sign rule. The final bin contains the last single point. This different aggregation does not recover the individual consecutive runs. The table stores n_saved_frames and endpoints for each bin.

Definitions derive from the unchanged run_time_anatomy_v0.py and run_hsp90_v1.py producer scripts. The original tables are retained without editing. The paper PDF is the source of record; the existing article text extraction is supplied for searching, with original line numbers retained. Verify equations and figure details in the PDF.

## 原生NOE对应判据
native_noe每轨迹open/closed_contact_violation.dat第一列保存序号1..1001，对应time_ns20..1020；第二列平均正上限违例Å（Vopen/Vclosed），第三列历史pseudo-distance。后者差值用于原contact_margin，不当原生违例。开放方向为geometry_delta_A>0且contact_margin_A>0。主容差τ=1Å，敏感性0.5/2Å；OPEN_NOE=Vopen≤τ<Vclosed，CLOSED_NOE反之，BOTH_FAR两者>τ，BOTH_NEAR两者≤τ。在开放方向帧中OPEN_NOE比例≥0.8为一致；否则BOTH_FAR比例≥0.5为只相对偏好；其余部分；无开放方向为不适用。另以开放起始组Vopen所有帧的95分位为参照带，连续50个保存点进入为entry；该同数据参照不是独立验证。
