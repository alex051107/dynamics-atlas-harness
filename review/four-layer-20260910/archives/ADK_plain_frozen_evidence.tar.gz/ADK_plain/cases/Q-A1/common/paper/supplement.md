                              Supplementary Materials for
          Tracking the ATP-binding response in adenylate kinase in real time

            Fredrik Orädd, Harsha Ravishankar, Jack Goodman, Per Rogne, Lars Backman,
               Annette Duelli, Martin Nors Pedersen, Matteo Levantino, Michael Wulff,
                               Magnus Wolf-Watz, Magnus Andersson*


                          *Corresponding author. Email: magnus.p.andersson@umu.se

                          Published 17 November 2021, Sci. Adv. 7, eabi5514 (2021)
                                        DOI: 10.1126/sciadv.abi5514

This PDF file includes:

       Figs. S1 to S7
       Table S1
Fig. S1. Corrections of heating effects, negative time delay, and caged ATP photolysis. (A) A
heating difference curve was obtained from time-resolved X-ray scattering of a dye solution (red)
and was scaled to the TR-XSS data (black – exemplified here by the 6-ms time point) by alignment
in the 1.7 Å-1 < q < 2.2 Å-1 region where the effects from solvent expansion are observed and
subtracted to give the heating-corrected difference curve (blue). (B) Comparison of late basis
spectra with (red) and without (black) correction for the negative time delay. (C) TR-XSS
experimental data of caged ATP without protein scaled to the late basis spectrum and (D) late basis
spectra with (red) and without (black) caged ATP correction.
Fig. S2. Omitting concentration-dependent effects from the TR-XSS data. (A) Guinier plot based
on the TR-XSS data showing low-q values that deviate from linearity and hence is subjected to
concentration-dependent effects. The slope calculates to a radius of gyration of 15 Å, which agrees
with crystal structure radii of gyration of 16 Å (closed state) and 19 Å (open state). (B) The late
basis spectrum with (red) and without (black) omitting concentration-dependent low-q data.
Fig. S3. Singular value decomposition (SVD) analysis of the time-resolved X-ray scattering data.
(A) The first (black) and second (red) SVD components (B) Relative amplitudes of the two major
components at each time point in the dataset.
Fig. S4. Structural characterization of the time-resolved X-ray data. (A) C𝛼 distance difference
matrix for the open and closed crystal structures (PDB ID: 4AKE and 1AKE, respectively). (B) R-
factors for the 10 best (black) and worst (red) fitting sets of structural pairs and their corresponding
RMSD values.
Fig. S5. Secondary structure analysis of the NMPbd and CORE regions in AdK. The secondary
structure in the simulations of the NMPbd (residue 30-67) in the A, open and B, closed AdK states,
and for the CORE (residue 1-29, 68-115, 161-214) region in the C, open and D, closed AdK states.
Random coil, b-sheet, and a-helix secondary structures displayed as black, red, and blue lines,
respectively.
Fig. S6. Salt-bridge stabilization of the LIDbd in AdK. The salt bridge between Arg131 and
Asp146 in the ATPbd is shown for the closed AdK crystal structure (left) with detailed relevant
distances (right).
Fig. S7. Representative isothermal calorimetry thermograms for Ap5A binding to adenylate kinase.
Heat traces were obtained by injecting Ap5A to wild-type or Arg131Ala adenylate kinase. After
integration, a single-site-binding isotherm was fitted to the data to obtain the enthalpy of binding
ΔH, entropy ΔS and the dissociation constant Kd. Best fitting dissociation constants for the Ap5A
binding to the wild-type and Arg131Ala were 354±72 and 576±30 nM, respectively, for the data
displayed in the figure. The first point in ITC titration was not included in the fitting. Data shown
are representative of four independent experiments. In all figures, circles represent experimental
data and the full drawn red line the best fit.
 Variant      DH0 (kcal mol-1)   -TDS0 (kcal mol-1)   DG0 (kcal mol-1)   Kd (nM)
 Arg131Ala    -27 ± 0.3          18.4 ± 0.3           -8.5 ± 0.1         576 ± 30
 Wild-type    -5.0 ± 1.3         -3.8 ± 1.2           -8.8 ± 0.1         354 ± 72

              kcat (s-1)         KM (µM)
 Arg131Ala    250 ± 5            140 ± 20
 Wild-type    360 ± 10           63 ± 10


Table S1. Binding- and catalytic parameters of Arg131Ala and wild-type AdK.
